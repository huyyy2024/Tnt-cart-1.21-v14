package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.util.BowTrajectoryUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks into ArrowEntity#tick (class_1665 -> method_5773).
 *
 * On first tick of a flaming arrow entity that belongs to our player:
 *   1. Compute predicted landing position from current trajectory.
 *   2. Hand off to FireBowRuntime#acceptArrow — entirely async from here.
 *
 * No slot switches happen in this mixin. The slot guard lives in FireBowRuntime.
 */
@Environment(EnvType.CLIENT)
@Mixin(net.minecraft.entity.projectile.ArrowEntity.class)
public abstract class FireArrowMixin {

    /** Tracks whether this specific entity instance has already been accepted. */
    private boolean firebow$accepted = false;

    @Inject(method = "tick", at = @At("HEAD"))
    private void firebow$onTick(CallbackInfo ci) {
        if (firebow$accepted) return;

        FireBowRuntime runtime = FireBowRuntime.get();
        if (!runtime.isEnabled()) return;

        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity localPlayer = client.player;
        if (localPlayer == null || client.world == null) return;

        ArrowEntity self = (ArrowEntity)(Object)this;

        // Only handle arrows that belong to the local player and are on fire
        if (self.getOwner() == null) return;
        if (self.getOwner().getId() != localPlayer.getId()) return;
        if (!self.isOnFire()) return;

        firebow$accepted = true;

        // Predict landing from current velocity snapshot
        // We capture this on the render/client thread synchronously, then hand off
        int savedSlot = localPlayer.getInventory().selectedSlot;
        int useTimeLeft = localPlayer.getItemUseTimeLeft();

        BlockPos landingPos = BowTrajectoryUtil.predictLanding(localPlayer, useTimeLeft);

        runtime.acceptArrow(self.getId(), landingPos, savedSlot);
    }
}
