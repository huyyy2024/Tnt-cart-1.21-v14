package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.util.BowTrajectoryUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Tracks whether the local player is currently drawing a bow.
 *
 * This flag is consumed by FireBowRuntime before any slot switch to prevent
 * the slot change from interrupting an active draw (which caused the original
 * tick-collision bug when bow release was detected via ClientConnection).
 *
 * Injecting into sendMovementPackets (method_3136) at HEAD gives us a
 * per-tick snapshot just before position sync — same as the original mod.
 * No bow-release logic lives here anymore.
 */
@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void firebow$beforeSync(CallbackInfo ci) {
        ClientPlayerEntity self = (ClientPlayerEntity)(Object)this;
        boolean drawing = BowTrajectoryUtil.isHoldingBow(self) && self.isUsingItem();
        FireBowRuntime.get().playerIsDrawingBow = drawing;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void firebow$onTick(CallbackInfo ci) {
        // kept for future extension; currently a no-op
    }
}
