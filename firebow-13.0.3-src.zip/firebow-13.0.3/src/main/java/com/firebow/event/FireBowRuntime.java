package com.firebow.event;

import com.firebow.target.PlacementTarget;
import com.firebow.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Core runtime for FireBow mod — 1.21 clean version.
 *
 * Key design decisions for 1.21 compatibility:
 *  - NO ClientConnectionMixin: method_52906 (send(Packet,ChannelFutureListener,boolean))
 *    was added in 1.21.11 and does not exist in 1.21. Removed entirely.
 *  - Bow release detection: switched from packet-intercept to arrow entity tracking
 *    via FireArrowMixin (tick HEAD on AbstractArrowEntity). No slot switch happens
 *    while the player is actively drawing the bow — guard is checked before every
 *    slot change.
 *  - acceptArrow() is called from FireArrowMixin the moment a new fire-arrow entity
 *    tick is first seen. We then run the place sequence fully async, restoring the
 *    slot only after the interaction packets are sent.
 */
public class FireBowRuntime {
    public static final FireBowRuntime INSTANCE = new FireBowRuntime();

    private static final long ARROW_DEDUP_WINDOW_MS = 800L;
    private static final int MAX_CART_RETRIES = 3;

    /** entityId -> last-accepted timestamp (ms) */
    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();

    /** positions where a rail was recently placed, to skip duplicate cart triggers */
    private final Set<BlockPos> recentDone = Collections.newSetFromMap(new ConcurrentHashMap<>());

    private final TickSynchronizer tickSync = new TickSynchronizer();

    private volatile boolean enabled = false;

    // ------------------------------------------------------------------ state
    /**
     * Whether the local player is currently in an active bow draw.
     * Set by ClientPlayerEntityMixin, read by onClientTick before slot changes.
     */
    public volatile boolean playerIsDrawingBow = false;

    private FireBowRuntime() {}

    public static FireBowRuntime get() { return INSTANCE; }

    // ------------------------------------------------------------------ API
    public boolean isEnabled() { return enabled; }

    public void toggle() {
        enabled = !enabled;
        if (!enabled) {
            acceptedArrows.clear();
            recentDone.clear();
        }
    }

    // ------------------------------------------------------------------ tick
    /** Called from ClientTickMixin (MinecraftClient#tick HEAD). */
    public void onClientTick(MinecraftClient client) {
        tickSync.onClientTick();

        if (!enabled || client.player == null) return;

        // Drain recentDone — keep it bounded
        if (recentDone.size() > 64) recentDone.clear();

        processPendingRails(client);
    }

    // ------------------------------------------------------------------ arrow
    /**
     * Called from FireArrowMixin when a fire-arrow entity ticks for the first time
     * in this client's world.
     *
     * @param entityId   the arrow entity's numeric id
     * @param predictedPos where PlacementCalc / BowTrajectoryUtil computed the landing
     * @param savedSlot  hotbar slot the player was on when the arrow was fired
     */
    public void acceptArrow(int entityId, BlockPos predictedPos, int savedSlot) {
        if (!enabled) return;
        if (isDuplicateArrow(entityId)) return;
        acceptedArrows.put(entityId, System.currentTimeMillis());

        // Run the full sequence off the main thread
        AsyncRunner.run(() -> executeSequence(predictedPos, savedSlot));
    }

    private boolean isDuplicateArrow(int entityId) {
        Long last = acceptedArrows.get(entityId);
        if (last == null) return false;
        return (System.currentTimeMillis() - last) < ARROW_DEDUP_WINDOW_MS;
    }

    // ------------------------------------------------------------------ pendingRails
    // pendingRails: BlockPos -> [cartDelayTicks, retriesLeft]
    private final Map<BlockPos, int[]> pendingRails = new ConcurrentHashMap<>();

    private void processPendingRails(MinecraftClient client) {
        if (pendingRails.isEmpty()) return;
        ClientPlayerEntity player = client.player;
        if (player == null) return;

        var iter = pendingRails.entrySet().iterator();
        while (iter.hasNext()) {
            var entry = iter.next();
            BlockPos railPos = entry.getKey();
            int[] state = entry.getValue();

            state[0]--; // countdown ticks
            if (state[0] > 0) continue;

            // Check world: did the rail get placed?
            if (!client.world.getBlockState(railPos).isOf(net.minecraft.block.Blocks.RAIL)) {
                state[1]--;
                if (state[1] <= 0) { iter.remove(); continue; }
                state[0] = 2; // retry in 2 ticks
                continue;
            }

            // Rail exists — place the cart
            // Guard: do NOT switch slots while the player is drawing
            if (playerIsDrawingBow) {
                // defer one more tick
                state[0] = 1;
                continue;
            }

            SearchResult cartSlot = com.firebow.util.InventoryUtil.findItem(Items.TNT_MINECART);
            if (cartSlot.isMissing()) { iter.remove(); continue; }

            int prev = player.getInventory().selectedSlot;
            player.getInventory().selectedSlot = cartSlot.slot;

            InteractionUtil.placeOnTop(client, railPos);

            player.getInventory().selectedSlot = prev;
            recentDone.add(railPos);
            iter.remove();
        }
    }

    // ------------------------------------------------------------------ sequence
    private void executeSequence(BlockPos targetPos, int savedSlot) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        PlacementTarget target = PlacementTarget.tryCreate(targetPos);
        if (target == null) return;
        if (recentDone.contains(targetPos)) return;

        // --- place rail ---
        // Wait for next client tick so slot switch happens cleanly
        tickSync.awaitNextTick(500L);

        client.execute(() -> {
            ClientPlayerEntity player = client.player;
            if (player == null) return;
            // Guard: never switch slots while bow is being drawn
            if (playerIsDrawingBow) return;

            int prev = player.getInventory().selectedSlot;
            player.getInventory().selectedSlot = target.railSlot.slot;
            InteractionUtil.placeBelow(client, targetPos.up()); // places on top of block below target
            player.getInventory().selectedSlot = prev;
        });

        // Schedule cart placement: wait for rail to appear, then place cart
        // Uses pendingRails so the main tick loop handles it with the draw-guard
        long cartDelayTicks = Math.max(2, PingUtil.getPingMs(client) / 50 + 2);
        pendingRails.put(targetPos, new int[]{(int) cartDelayTicks, MAX_CART_RETRIES});
    }
}
