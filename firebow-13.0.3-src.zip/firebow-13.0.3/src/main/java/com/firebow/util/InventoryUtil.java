package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.function.Predicate;

public class InventoryUtil {
    public static SearchResult findInHotbar(Predicate<ItemStack> predicate) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return SearchResult.MISSING;
        var inv = client.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty() && predicate.test(stack)) {
                return SearchResult.of(i);
            }
        }
        return SearchResult.MISSING;
    }

    public static SearchResult findItem(Item item) {
        return findInHotbar(stack -> stack.getItem() == item);
    }

    public static SearchResult findAny(Item... items) {
        return findInHotbar(stack -> {
            for (Item item : items) {
                if (stack.getItem() == item) return true;
            }
            return false;
        });
    }
}
