package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class BowTrajectoryUtil {
    public static BlockPos predictLanding(ClientPlayerEntity player, int useTimeLeft) {
        World world = player.getWorld();
        int usedTicks = player.getItemUseTimeLeft() - useTimeLeft;
        // BowItem.getPullProgress uses max 20 ticks
        float pullProgress = BowItem.getPullProgress(usedTicks);
        float speed = pullProgress * pullProgress * 3.0f;

        float gravity = world.getDimension().piglinSafe() ? 0.05f : 0.05f;
        double yawRad = Math.toRadians(player.getYaw());
        double pitchRad = Math.toRadians(player.getPitch());

        double len = Math.cos(-pitchRad);
        Vec3d eye = player.getEyePos();
        Vec3d velocity = new Vec3d(
            -Math.sin(yawRad) * len * speed,
            -Math.sin(pitchRad) * speed,
            Math.cos(yawRad) * len * speed
        );

        BlockPos rail = PlacementCalc.predictLandingRailPos(world, eye, velocity);

        // Check air above and that block below is solid
        if (!world.getBlockState(rail).isAir()) {
            rail = world.getBlockState(rail.up()).isAir() ? rail.up() : rail;
        }
        return rail;
    }

    public static boolean isHoldingBow(ClientPlayerEntity player) {
        ItemStack main = player.getMainHandStack();
        ItemStack off = player.getOffHandStack();
        return main.getItem() instanceof BowItem || off.getItem() instanceof BowItem;
    }
}
