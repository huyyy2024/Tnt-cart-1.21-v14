package com.firebow.util;

public class SearchResult {
    public static final SearchResult MISSING = new SearchResult(-1, false);

    public final int slot;
    public final boolean found;

    public SearchResult(int slot, boolean found) {
        this.slot = slot;
        this.found = found;
    }

    public static SearchResult of(int slot) {
        return new SearchResult(slot, true);
    }

    public boolean isMissing() {
        return !found;
    }
}
