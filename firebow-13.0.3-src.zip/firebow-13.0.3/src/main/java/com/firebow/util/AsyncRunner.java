package com.firebow.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AsyncRunner {
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "firebow-worker");
        t.setDaemon(true);
        return t;
    });

    public static void run(Runnable action) {
        EXECUTOR.execute(action);
    }

    public static void runDelayed(Runnable action, long delayMs) {
        EXECUTOR.execute(() -> {
            try {
                Thread.sleep(delayMs);
                action.run();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
}
