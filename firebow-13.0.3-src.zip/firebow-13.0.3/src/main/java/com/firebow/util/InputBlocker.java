package com.firebow.util;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class InputBlocker {
    private static final Set<String> OWNERS = ConcurrentHashMap.newKeySet();

    public static void block(String owner) {
        OWNERS.add(owner);
    }

    public static void unblock(String owner) {
        OWNERS.remove(owner);
    }

    public static boolean isBlocked() {
        return !OWNERS.isEmpty();
    }
}
