package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class RotationUtil {
    public static float[] calcRotation(ClientPlayerEntity player, BlockPos target) {
        Vec3d eyes = player.getEyePos();
        Vec3d tVec = Vec3d.ofCenter(target);
        double dx = tVec.x - eyes.x;
        double dy = tVec.y - eyes.y;
        double dz = tVec.z - eyes.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        yaw = MathHelper.wrapDegrees(yaw);
        pitch = MathHelper.clamp(pitch, -90f, 90f);
        return new float[]{yaw, pitch};
    }

    public static void applySilent(ClientPlayerEntity player, float[] rotation) {
        player.setYaw(rotation[0]);
        player.setPitch(rotation[1]);
    }

    public static boolean inReach(ClientPlayerEntity player, BlockPos target) {
        double dist = player.getEyePos().distanceTo(Vec3d.ofCenter(target));
        return dist <= 4.5;
    }
}
