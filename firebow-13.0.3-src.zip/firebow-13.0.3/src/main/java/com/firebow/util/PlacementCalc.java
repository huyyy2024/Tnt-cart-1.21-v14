package com.firebow.util;

import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class PlacementCalc {
    private static final double GRAVITY = 0.05;
    private static final double DRAG = 0.99;
    private static final int MAX_TICKS = 120;

    public static BlockPos predictLandingRailPos(World world, Vec3d pos, Vec3d velocity) {
        double x = pos.x, y = pos.y, z = pos.z;
        double vx = velocity.x, vy = velocity.y, vz = velocity.z;
        BlockPos prev = BlockPos.ofFloored(x, y, z);

        for (int t = 0; t < MAX_TICKS; t++) {
            double nx = x + vx;
            double ny = y + vy;
            double nz = z + vz;
            vy -= GRAVITY;
            vx *= DRAG;
            vy *= DRAG;
            vz *= DRAG;

            BlockPos cur = BlockPos.ofFloored(nx, ny, nz);
            if (!world.getBlockState(cur).isAir()) {
                return findRailPos(world, prev);
            }
            prev = cur;
            x = nx; y = ny; z = nz;
        }
        return findRailPos(world, prev);
    }

    private static BlockPos findRailPos(World world, BlockPos start) {
        for (int dy = 0; dy >= -4; dy--) {
            BlockPos candidate = start.add(0, dy, 0);
            BlockPos below = candidate.down();
            if (world.getBlockState(candidate).isAir() && isSolidGround(world, below)) {
                return candidate;
            }
        }
        return start;
    }

    private static boolean isSolidGround(World world, BlockPos pos) {
        var state = world.getBlockState(pos);
        return state.isSolidBlock(world, pos) &&
               !state.isOf(Blocks.RAIL) &&
               !state.isOf(Blocks.POWERED_RAIL) &&
               !state.isOf(Blocks.DETECTOR_RAIL);
    }
}
