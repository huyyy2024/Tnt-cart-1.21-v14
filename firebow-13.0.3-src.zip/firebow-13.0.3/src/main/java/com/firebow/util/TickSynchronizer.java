package com.firebow.util;

public class TickSynchronizer {
    private final Object monitor = new Object();
    private volatile long currentTick = 0;

    public void onClientTick() {
        synchronized (monitor) {
            currentTick++;
            monitor.notifyAll();
        }
    }

    public long getCurrentTick() {
        return currentTick;
    }

    public boolean awaitNextTick(long timeoutMs) {
        long target = currentTick + 1;
        long deadline = System.nanoTime() + timeoutMs * 1_000_000L;
        synchronized (monitor) {
            while (currentTick < target) {
                long remaining = deadline - System.nanoTime();
                if (remaining <= 0) return false;
                try {
                    monitor.wait(remaining / 1_000_000, (int)(remaining % 1_000_000));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return false;
                }
            }
        }
        return true;
    }
}
