package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class InteractionUtil {
    public static boolean placeOnTop(MinecraftClient client, BlockPos pos) {
        return place(client, pos, Direction.UP, Vec3d.ofCenter(pos).add(0, 0.5, 0));
    }

    public static boolean placeBelow(MinecraftClient client, BlockPos pos) {
        BlockPos below = pos.down();
        return place(client, below, Direction.UP, Vec3d.ofCenter(below).add(0, 0.5, 0));
    }

    private static boolean place(MinecraftClient client, BlockPos pos, Direction face, Vec3d hitVec) {
        try {
            ClientPlayerEntity player = client.player;
            ClientPlayerInteractionManager im = client.interactionManager;
            if (player == null || im == null) return false;
            player.setSprinting(false);
            BlockHitResult hit = new BlockHitResult(hitVec, face, pos, false);
            im.interactBlock(player, Hand.MAIN_HAND, hit);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean inReach(ClientPlayerEntity player, BlockPos pos) {
        Vec3d eyes = player.getEyePos();
        Vec3d center = Vec3d.ofCenter(pos);
        return eyes.distanceTo(center) <= 4.5;
    }
}
