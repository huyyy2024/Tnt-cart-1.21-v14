package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

public class PingUtil {
    public static long getPingMs(MinecraftClient client) {
        try {
            if (client.player == null) return 0L;
            PlayerListEntry entry = client.player.networkHandler.getPlayerListEntry(client.player.getUuid());
            if (entry == null) return 0L;
            long ping = entry.getLatency();
            long lagBonus = ping / 2;
            return lagBonus;
        } catch (Exception e) {
            return 0L;
        }
    }
}
