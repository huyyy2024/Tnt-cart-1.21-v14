package com.firebow;

import com.firebow.event.FireBowRuntime;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FireBowClient implements ClientModInitializer {
    public static final String MOD_ID = "firebow";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[FireBow] v13.0.3 loaded (1.21 clean)");

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.firebow.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_J,
            "category.firebow"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            if (toggleKey.wasPressed()) {
                FireBowRuntime.get().toggle();
                boolean on = FireBowRuntime.get().isEnabled();
                client.player.sendMessage(
                    Text.literal(on ? "§a[FireBow] §fBật ✔" : "§c[FireBow] §fTắt ✘"),
                    true
                );
            }
        });
    }
}
